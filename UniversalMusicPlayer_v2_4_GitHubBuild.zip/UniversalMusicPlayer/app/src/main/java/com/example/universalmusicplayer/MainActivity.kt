package com.example.universalmusicplayer

import android.content.Intent
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MusicPlayerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicPlayerApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tracks by remember { mutableStateOf(emptyList<MusicTrack>()) }
    var selectedTrack by remember { mutableStateOf<MusicTrack?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showLyrics by remember { mutableStateOf(false) }
    var showEqualizer by remember { mutableStateOf(false) }
    var originalLyrics by remember { mutableStateOf("") }
    var translatedLyrics by remember { mutableStateOf("") }
    var syncedLyrics by remember { mutableStateOf("") }
    var lyricsStatus by remember { mutableStateOf("Choose a song to find lyrics automatically.") }
    var lyricsLoading by remember { mutableStateOf(false) }
    var lyricsDisplayMode by remember { mutableIntStateOf(2) }
    var showTranslation by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<Long>() }
    var showFavoritesOnly by remember { mutableStateOf(false) }
    val latestTracks by rememberUpdatedState(tracks)
    var effectsController by remember { mutableStateOf<AudioEffectsController?>(null) }

    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
    fun refreshLibrary() { tracks = MusicRepository(context).loadSongs() }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) refreshLibrary()
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) searchText = spoken
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedTrack = latestTracks.firstOrNull { it.id.toString() == mediaItem?.mediaId }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); effectsController?.release(); player.release() }
    }

    DisposableEffect(player.audioSessionId) {
        val session = player.audioSessionId
        val controller = if (session != 0) runCatching { AudioEffectsController(session) }.getOrNull() else null
        effectsController = controller
        onDispose { controller?.release(); if (effectsController === controller) effectsController = null }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
        else permissionLauncher.launch(permission)
    }

    LaunchedEffect(isPlaying, player) {
        while (isPlaying) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            delay(250)
        }
        positionMs = player.currentPosition.coerceAtLeast(0L)
    }

    // Some devices create the audio session only after playback starts.
    LaunchedEffect(isPlaying, selectedTrack?.id) {
        if (isPlaying && effectsController == null) {
            delay(600)
            val session = player.audioSessionId
            if (session != 0) effectsController = runCatching { AudioEffectsController(session) }.getOrNull()
        }
    }

    LaunchedEffect(selectedTrack?.id) {
        val track = selectedTrack ?: return@LaunchedEffect
        originalLyrics = ""; translatedLyrics = ""; syncedLyrics = ""
        showTranslation = false; lyricsLoading = true
        val cached = withContext(Dispatchers.IO) { LyricsCache.get(context, track.title, track.artist) }
        if (cached != null) {
            originalLyrics = cached.original; translatedLyrics = cached.translation
            syncedLyrics = cached.syncedLyrics; lyricsStatus = cached.message
            lyricsLoading = false
            return@LaunchedEffect
        }
        lyricsStatus = "First play: searching online and learning lyrics…"
        try {
            val result = withContext(Dispatchers.IO) { LyricsService.fetchLyricsAndTranslation(track.title, track.artist) }
            originalLyrics = result.original; translatedLyrics = result.translation
            syncedLyrics = result.syncedLyrics; lyricsStatus = result.message
            if (result.original.isNotBlank()) {
                withContext(Dispatchers.IO) { LyricsCache.save(context, track.title, track.artist, result) }
                lyricsStatus += " Saved on this phone for future offline playback."
            }
        } catch (_: Exception) {
            lyricsStatus = "Lyrics could not be loaded. Check your internet connection and try this song again."
        } finally { lyricsLoading = false }
    }

    fun playTrack(track: MusicTrack) {
        val index = tracks.indexOfFirst { it.id == track.id }
        if (index < 0) return
        selectedTrack = track
        val items = tracks.map { MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri).build() }
        player.setMediaItems(items, index, 0L)
        player.shuffleModeEnabled = shuffleEnabled; player.repeatMode = repeatMode
        player.prepare(); player.play()
        showLyrics = false; showEqualizer = false
    }

    val visibleTracks = tracks.filter {
        (!showFavoritesOnly || favorites.contains(it.id)) &&
            (it.title.contains(searchText, true) || it.artist.contains(searchText, true))
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF8B7CFF),
        secondary = Color(0xFF42D9FF),
        background = Color(0xFF090914),
        surface = Color(0xFF151528)
    )) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Universal Music Player", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { showFavoritesOnly = !showFavoritesOnly; showLyrics = false; showEqualizer = false }) {
                            Icon(if (showFavoritesOnly) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorites")
                        }
                        IconButton(onClick = { showEqualizer = !showEqualizer; showLyrics = false }) {
                            Icon(Icons.Filled.Equalizer, "Equalizer")
                        }
                        TextButton(onClick = { showLyrics = !showLyrics; showEqualizer = false }) {
                            Icon(Icons.Filled.Lyrics, null); Spacer(Modifier.width(4.dp))
                            Text(if (showLyrics) "Songs" else "Lyrics")
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when {
                    showLyrics -> LyricsScreen(
                        track = selectedTrack, original = originalLyrics, translated = translatedLyrics,
                        synced = syncedLyrics, positionMs = positionMs, isPlaying = isPlaying,
                        loading = lyricsLoading, status = lyricsStatus, displayMode = lyricsDisplayMode,
                        onDisplayModeChange = { lyricsDisplayMode = it }, showTranslation = showTranslation,
                        onToggleTranslation = { showTranslation = it }
                    )
                    showEqualizer -> EqualizerScreen(effectsController)
                    else -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (showFavoritesOnly) "Your favourites" else "Your music", style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Search your music")
                                }
                                runCatching { voiceLauncher.launch(intent) }
                            }) { Icon(Icons.Filled.Mic, "Voice search") }
                            TextButton(onClick = {
                                if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
                                else permissionLauncher.launch(permission)
                            }) { Text("Rescan") }
                        }
                        OutlinedTextField(value = searchText, onValueChange = { searchText = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search songs or artists") })
                        Spacer(Modifier.height(8.dp))
                        if (visibleTracks.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(if (tracks.isEmpty()) "No music found. Allow audio access, add music to your phone, then tap Rescan." else "No matching songs found.", textAlign = TextAlign.Center)
                            }
                        } else {
                            LazyColumn(Modifier.weight(1f)) {
                                itemsIndexed(visibleTracks, key = { _, item -> item.id }) { _, track ->
                                    ListItem(
                                        leadingContent = { Icon(Icons.Filled.MusicNote, null) },
                                        headlineContent = { Text(track.title, maxLines = 1) },
                                        supportingContent = { Text(track.artist, maxLines = 1) },
                                        trailingContent = {
                                            IconButton(onClick = {
                                                if (favorites.contains(track.id)) favorites.remove(track.id) else favorites.add(track.id)
                                            }) { Icon(if (favorites.contains(track.id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favourite") }
                                        },
                                        modifier = Modifier.clickable { playTrack(track) }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                    }
                }

                // Compact now-playing lyrics preview remains visible while browsing.
                if (!showLyrics && !showEqualizer && selectedTrack != null) {
                    val timed = LyricsParser.parse(syncedLyrics)
                    val active = timed.indexOfLast { it.timeMs <= positionMs }.coerceAtLeast(0)
                    if (timed.isNotEmpty()) {
                        Text(timed[active].text, modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                            color = MaterialTheme.colorScheme.secondary, maxLines = 1, textAlign = TextAlign.Center)
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(selectedTrack?.title ?: "Nothing playing", style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(selectedTrack?.artist ?: "Choose a song from your library", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                PlaybackVisualizer(isPlaying, Modifier.fillMaxWidth().height(30.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shuffleEnabled = !shuffleEnabled; player.shuffleModeEnabled = shuffleEnabled }) {
                        Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToPreviousMediaItem() }) { Icon(Icons.Filled.SkipPrevious, "Previous") }
                    FilledIconButton(onClick = { if (player.isPlaying) player.pause() else if (selectedTrack != null) player.play() }, enabled = selectedTrack != null) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (isPlaying) "Pause" else "Play")
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, "Next") }
                    IconButton(onClick = {
                        repeatMode = when (repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }; player.repeatMode = repeatMode
                    }) {
                        Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat",
                            tint = if (repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(when (repeatMode) { Player.REPEAT_MODE_ONE -> "Repeat one"; Player.REPEAT_MODE_ALL -> "Repeat all"; else -> "Repeat off" },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun LyricsScreen(
    track: MusicTrack?, original: String, translated: String, synced: String,
    positionMs: Long, isPlaying: Boolean, loading: Boolean, status: String,
    displayMode: Int, onDisplayModeChange: (Int) -> Unit,
    showTranslation: Boolean, onToggleTranslation: (Boolean) -> Unit
) {
    val lines = remember(synced, original) {
        val parsed = LyricsParser.parse(synced)
        if (parsed.isNotEmpty()) parsed else original.lines().filter { it.isNotBlank() }.mapIndexed { index, line -> LyricLine(index * 5000L, line) }
    }
    val activeIndex = lines.indexOfLast { it.timeMs <= positionMs }.coerceAtLeast(0)
    val listState = rememberLazyListState()
    LaunchedEffect(activeIndex, displayMode, showTranslation) {
        if (lines.isNotEmpty()) listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
    }
    val translatedLines = remember(translated) { translated.lines() }
    Column(Modifier.fillMaxSize()) {
        Text("Live lyrics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(track?.let { "${it.title} • ${it.artist}" } ?: "No song selected", style = MaterialTheme.typography.bodySmall)
        if (loading) { LinearProgressIndicator(Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)) }
        if (original.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(selected = displayMode == 0, onClick = { onDisplayModeChange(0) }, shape = SegmentedButtonDefaults.itemShape(0, 3)) { Text("Both") }
                SegmentedButton(selected = displayMode == 1, onClick = { onDisplayModeChange(1) }, shape = SegmentedButtonDefaults.itemShape(1, 3)) { Text("Translation") }
                SegmentedButton(selected = displayMode == 2, onClick = { onDisplayModeChange(2) }, shape = SegmentedButtonDefaults.itemShape(2, 3)) { Text("Toggle") }
            }
            if (displayMode == 2) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lyrics language"); Spacer(Modifier.weight(1f))
                    Text(if (showTranslation) "Translation" else "Original", color = MaterialTheme.colorScheme.primary)
                    Switch(checked = showTranslation, onCheckedChange = onToggleTranslation, enabled = translated.isNotBlank())
                }
            }
            if (synced.isBlank()) Text("This song has plain lyrics only; line highlighting follows an estimated 5-second pace.", style = MaterialTheme.typography.labelSmall)
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 24.dp)) {
                itemsIndexed(lines) { index, line ->
                    val isActive = index == activeIndex
                    val translatedLine = translatedLines.getOrNull(index).orEmpty()
                    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isActive) Color(0x332E8BFF) else Color.Transparent)
                        .padding(horizontal = 14.dp, vertical = 12.dp)) {
                        if (displayMode != 1) {
                            Text(line.text, style = if (isActive) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                color = if (isActive) Color(0xFF8CEBFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (displayMode == 0 || (displayMode == 2 && showTranslation)) {
                            val t = translatedLine.ifBlank { if (index == 0 && translatedLines.size != lines.size) translated else "" }
                            if (t.isNotBlank()) Text(t, modifier = Modifier.padding(top = 4.dp),
                                style = if (isActive) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
                                color = if (isActive) Color(0xFFC8BFFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (displayMode == 1 && translated.isNotBlank()) {
                            val t = translatedLine.ifBlank { if (index == 0) translated else "" }
                            if (t.isNotBlank()) Text(t, style = if (isActive) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                color = if (isActive) Color(0xFF8CEBFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(if (loading) "Looking for lyrics…" else status, textAlign = TextAlign.Center)
            }
        }
        if (status.isNotBlank()) Text(status, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Word-level timing is shown only when supplied by the lyrics source. Lyrics saved on this phone remain available offline.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlaybackVisualizer(isPlaying: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "visualizer")
    val phase by transition.animateFloat(0f, (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    Canvas(modifier) {
        val count = thirtyBars
        val gap = size.width * 0.012f
        val barWidth = (size.width - gap * (count - 1)) / count
        for (i in 0 until count) {
            val wave = (sin(phase + i * 0.72f) * 0.5f + 0.5f)
            val height = if (isPlaying) size.height * (0.18f + wave * 0.78f) else size.height * 0.12f
            drawRoundRect(
                color = Color(0xFF5D75FF).copy(alpha = if (isPlaying) 0.55f + wave * 0.4f else 0.25f),
                topLeft = androidx.compose.ui.geometry.Offset(i * (barWidth + gap), (size.height - height) / 2),
                size = androidx.compose.ui.geometry.Size(barWidth, height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2)
            )
        }
    }
}
private const val thirtyBars = 30

@Composable
private fun EqualizerScreen(controller: AudioEffectsController?) {
    var bass by remember(controller) { mutableFloatStateOf(controller?.bassStrength?.toFloat() ?: 0f) }
    val levels = remember(controller) {
        mutableStateListOf<Float>().apply {
            if (controller != null) for (i in 0 until controller.bandCount) add(controller.getBandLevel(i).toFloat() / 100f)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Text("Audio equalizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Adjust the sound for this device's audio engine.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        if (controller == null) {
            Text("The device audio equalizer is not available yet. Start playback and reopen this screen.", textAlign = TextAlign.Center)
        } else {
            Text("Frequency bands (${controller.bandCount} supported)", fontWeight = FontWeight.SemiBold)
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(levels) { index, level ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Row { Text(controller.bandLabel(index)); Spacer(Modifier.weight(1f)); Text("${(level / 10f).toInt()} dB") }
                        Slider(value = level, onValueChange = {
                            levels[index] = it
                            controller.setBandLevel(index, (it * 100f).toInt())
                        }, valueRange = -15f..15f)
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("Bass boost", fontWeight = FontWeight.SemiBold)
                    Slider(value = bass, onValueChange = { bass = it; controller.setBassStrength(it.toInt() * 10) }, valueRange = 0f..100f)
                    Text("${bass.toInt()}%")
                }
            }
        }
        Text("Available frequency bands depend on your phone's audio hardware.", style = MaterialTheme.typography.labelSmall)
    }
}
