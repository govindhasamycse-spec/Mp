package com.example.universalmusicplayer

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Online first-play lookup. LRCLIB can provide both plain and timestamped LRC lyrics. */
data class LyricsResult(
    val original: String,
    val translation: String,
    val message: String,
    val syncedLyrics: String = ""
)

object LyricsService {
    fun fetchLyricsAndTranslation(title: String, artist: String): LyricsResult {
        val found = findLyrics(title, artist)
            ?: return LyricsResult("", "", "No matching lyrics were found online for this song.")
        val original = found.first.ifBlank { stripTimestamps(found.second) }
        val sourceLanguage = if (containsTamil(original)) "ta" else "en"
        val targetLanguage = if (sourceLanguage == "ta") "en" else "ta"
        val translation = try { translateText(original, sourceLanguage, targetLanguage) } catch (_: Exception) { "" }
        val label = if (sourceLanguage == "ta") "Tamil" else "English / other"
        val timing = if (found.second.isNotBlank()) " Timestamped lyrics saved." else " Only plain lyrics were available."
        val message = if (translation.isBlank()) "$label lyrics found. Translation is temporarily unavailable.$timing"
            else "$label lyrics found. Translation is ready.$timing"
        return LyricsResult(original, translation, message, found.second)
    }

    /** Returns plain lyrics and synced LRC separately. */
    private fun findLyrics(title: String, artist: String): Pair<String, String>? {
        val base = "https://lrclib.net/api/get?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val exact = runCatching { requestJson(base) }.getOrNull()
        if (exact != null) {
            val plain = exact.optString("plainLyrics").trim()
            val synced = exact.optString("syncedLyrics").trim()
            if (plain.isNotBlank() || synced.isNotBlank()) return Pair(plain, synced)
        }
        val searchUrl = "https://lrclib.net/api/search?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val results = runCatching { requestJsonArray(searchUrl) }.getOrNull() ?: return null
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val plain = item.optString("plainLyrics").trim()
            val synced = item.optString("syncedLyrics").trim()
            if (plain.isNotBlank() || synced.isNotBlank()) return Pair(plain, synced)
        }
        return null
    }

    private fun translateText(text: String, from: String, to: String): String =
        text.lines().map { line -> if (line.isBlank()) "" else runCatching { translateChunk(line, from, to) }.getOrDefault(line) }
            .joinToString("\n").takeIf { it.isNotBlank() } ?: ""

    private fun translateChunk(line: String, from: String, to: String): String {
        val url = "https://api.mymemory.translated.net/get?q=${enc(line.take(430))}&langpair=$from|$to"
        return requestJson(url).optJSONObject("responseData")?.optString("translatedText")?.takeIf { it.isNotBlank() } ?: line
    }

    private fun stripTimestamps(lrc: String): String = lrc.lineSequence()
        .map { it.replace(Regex("\\[\\d{2}:\\d{2}(?:\\.\\d{1,3})?]"), "").trim() }
        .filter { it.isNotBlank() }.joinToString("\n")

    private fun containsTamil(text: String) = text.any { it.code in 0x0B80..0x0BFF }
    private fun clean(value: String) = value.replace(Regex("\\s*\\([^)]*\\)\\s*$"), "").replace(Regex("\\s*\\[[^]]*]\\s*$"), "").trim()
    private fun enc(value: String) = URLEncoder.encode(value, "UTF-8")

    private fun requestJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"; connection.connectTimeout = 12000; connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.4 (Android)")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally { connection.disconnect() }
    }

    private fun requestJsonArray(url: String): org.json.JSONArray {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"; connection.connectTimeout = 12000; connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.4 (Android)")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return org.json.JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
        } finally { connection.disconnect() }
    }
}
