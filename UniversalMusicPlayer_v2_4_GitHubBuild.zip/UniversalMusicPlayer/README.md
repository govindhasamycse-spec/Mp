# Universal Music Player v2.4

Android local music player built with Kotlin, Jetpack Compose and Media3 ExoPlayer.

## Features
- Local music library, search, favourites, shuffle and repeat
- Automatic online lyrics lookup with offline on-device lyrics/translation cache
- Timestamped line-by-line lyrics highlighting and automatic scrolling when LRC timing is available
- Original / translation / both display modes
- Device audio-session equalizer and bass boost (the number of frequency bands depends on the phone)
- Animated in-app playback visualizer
- Voice search using the Android speech-recognition activity

## Important notes
- Word-by-word karaoke requires word-level timestamps. The LRCLIB response currently provides line timestamps, so this version highlights timed lines, not individual words.
- The visualizer is an animated playback indicator, not an audio-frequency analyzer.
- Voice search depends on a speech-recognition app/service installed on the phone.
- Lyrics and translations require internet on first lookup. Successfully learned lyrics are cached on the device for offline use.
- The equalizer uses Android's audio effects for the active playback session. Supported bands and effect availability vary by device.

## Build
The GitHub Actions workflow in `.github/workflows/android.yml` builds a debug APK on pushes to `main` or manual workflow dispatch.
