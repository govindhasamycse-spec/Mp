# Universal Music Player 2.3

An Android local-music player built with Kotlin, Jetpack Compose and Media3 ExoPlayer.

## Version 2.3 — Learn lyrics once

- On the first play, the app searches LRCLIB online using the song title and artist.
- It retrieves plain lyrics and timestamped LRC lyrics when the provider has them.
- It creates a best-effort Tamil/English translation online.
- Original lyrics, translation and available timestamps are saved locally on the phone.
- From the second play onwards, saved lyrics are loaded from local storage without an internet request.
- Both original and translated lyrics remain available offline after they have been saved.
- The local cache is keyed by normalized song title and artist, so it can be reused if the media item ID changes.

## Important limitations

This release uses online lyric lookup; it does not listen to the audio and generate a brand-new transcript when a provider has no lyrics. Lyrics availability and matching depend on track metadata and LRCLIB coverage. Translation is best-effort and may be rate-limited. Timestamped lyrics are preserved when supplied by LRCLIB; plain lyrics do not contain timing information.

The first lookup and translation require internet. Once successfully saved, both language versions can be shown offline. Clearing app data or uninstalling the app removes the local lyrics cache.

## Existing player features

- Local audio library scanning
- Shuffle and repeat off / all / one
- Previous, play/pause and next controls
- Search by song title or artist
- Session favourites filter
- Original + translation, translation-only and original/translation toggle modes

## Build APK with GitHub Actions

The included workflow builds a debug APK using Gradle 8.9 and JDK 17. Push the project to `main` or run the workflow manually from GitHub Actions. Download `UniversalMusicPlayer-v2.3-debug-apk` from the workflow Artifacts section.

## Requirements

- JDK 17 and Gradle 8.9 (provided by GitHub Actions)
- Android compile SDK 35 for local builds
