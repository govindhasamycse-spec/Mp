# Universal Music Player 2.2

An Android local-music player built with Kotlin, Jetpack Compose and Media3 ExoPlayer.

## Version 2.0 features

- Local audio library scanning with Android media permissions
- Shuffle playback
- Repeat off / repeat all / repeat one
- Previous, play/pause and next controls
- Search by song title or artist
- Session favourites filter
- Automatic online lyrics lookup using LRCLIB
- Best-effort automatic Tamil/English translation using MyMemory
- Original lyrics / translated lyrics toggle

## Online service notes

- Local playback works independently of the lyrics services.
- Automatic lyrics and translation require an internet connection.
- Lyrics are not guaranteed for every track. Matching depends on the metadata stored with the audio file (title and artist) and provider availability.
- The app detects Tamil-script lyrics and translates them to English; other detected/non-Tamil lyrics are translated to Tamil. This is a lightweight script-based choice, not full language identification.
- Translation is best-effort and may be rate-limited or unavailable. Translation quality can vary. The app does not contain a manual lyrics or translation editor.
- LRCLIB and MyMemory are third-party services; their availability and terms can change.

## Build APK with GitHub Actions

The included `.github/workflows/android.yml` builds a debug APK using Gradle 8.9 and JDK 17. Push the project to the `main` branch or run the workflow manually from the GitHub Actions tab. Download `UniversalMusicPlayer-v2.2-debug-apk` from the workflow's Artifacts section.

## Requirements

- Android Studio / Android SDK with compile SDK 35 for local builds, or GitHub Actions
- JDK 17
- Gradle 8.9

## Lyrics display modes (v2.1)
The lyrics screen supports all three display preferences: original and translation together, translation only, and a toggle between original and translation. Lyrics are looked up automatically using track title and artist; translation is best-effort between Tamil and English. Availability and accuracy depend on the online providers and track metadata.


## Version 2.2 updates
- Uses LRCLIB timestamped LRC lyrics when available.
- Automatically follows the current lyric line during playback and scrolls it into view.
- Highlights the active lyric line with a soft neon glow.
- Supports original, translated, and combined lyric display modes.
- Adds animated playback equalizer bars. These react to playback state; they are not an audio-frequency beat analyser.
- Falls back to plain lyrics when timestamped lyrics are unavailable; plain lyrics are not falsely presented as synchronised.
