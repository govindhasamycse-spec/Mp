package com.example.universalmusicplayer

import android.content.Context
import org.json.JSONObject
import java.security.MessageDigest

/** Small persistent on-device cache: once a track is learned, later plays need no network. */
object LyricsCache {
    private const val PREFS = "learned_song_lyrics_v23"

    fun get(context: Context, title: String, artist: String): LyricsResult? {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key(title, artist), null)
            ?: return null
        return runCatching {
            val json = JSONObject(raw)
            LyricsResult(
                original = json.optString("original"),
                translation = json.optString("translation"),
                message = "Learned lyrics loaded from this phone. Offline playback ready.",
                syncedLyrics = json.optString("syncedLyrics")
            )
        }.getOrNull()?.takeIf { it.original.isNotBlank() }
    }

    fun save(context: Context, title: String, artist: String, result: LyricsResult) {
        if (result.original.isBlank()) return
        val json = JSONObject().put("original", result.original)
            .put("translation", result.translation).put("syncedLyrics", result.syncedLyrics)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(key(title, artist), json.toString()).apply()
    }

    private fun key(title: String, artist: String): String {
        val normalized = (title.trim().lowercase() + "|" + artist.trim().lowercase())
        val bytes = MessageDigest.getInstance("SHA-256").digest(normalized.toByteArray())
        return bytes.joinToString("") { "%02x".format(it) }
    }
}
