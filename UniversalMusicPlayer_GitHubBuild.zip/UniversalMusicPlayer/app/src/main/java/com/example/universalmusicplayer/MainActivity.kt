package com.example.universalmusicplayer

import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MusicPlayerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicPlayerApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tracks by remember { mutableStateOf(emptyList<MusicTrack>()) }
    var selectedTrack by remember { mutableStateOf<MusicTrack?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showLyrics by remember { mutableStateOf(false) }
    var originalLyrics by remember { mutableStateOf("") }
    var translatedLyrics by remember { mutableStateOf("") }
    var lyricsStatus by remember { mutableStateOf("Choose a song to find lyrics automatically.") }
    var lyricsLoading by remember { mutableStateOf(false) }
    // 0 = original + translation, 1 = translation only, 2 = switch between them
    var lyricsDisplayMode by remember { mutableIntStateOf(2) }
    var showTranslation by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<Long>() }
    var showFavoritesOnly by remember { mutableStateOf(false) }

    val latestTracks by rememberUpdatedState(tracks)

    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE

    fun refreshLibrary() { tracks = MusicRepository(context).loadSongs() }

    val permissionLauncher = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted -> if (granted) refreshLibrary() }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedTrack = latestTracks.firstOrNull { it.id.toString() == mediaItem?.mediaId }
            }
        }
        player.addListener(listener)
        onDispose {
            player.removeListener(listener)
            player.release()
        }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
        else permissionLauncher.launch(permission)
    }

    LaunchedEffect(selectedTrack?.id) {
        val track = selectedTrack ?: return@LaunchedEffect
        originalLyrics = ""
        translatedLyrics = ""
        showTranslation = false
        lyricsLoading = true
        lyricsStatus = "Searching for lyrics…"
        try {
            val result = withContext(Dispatchers.IO) { LyricsService.fetchLyricsAndTranslation(track.title, track.artist) }
            originalLyrics = result.original
            translatedLyrics = result.translation
            lyricsStatus = result.message
        } catch (_: Exception) {
            lyricsStatus = "Lyrics could not be loaded. Check your internet connection and try another song."
        } finally {
            lyricsLoading = false
        }
    }

    fun playTrack(track: MusicTrack) {
        val index = tracks.indexOfFirst { it.id == track.id }
        if (index < 0) return
        selectedTrack = track
        val mediaItems = tracks.map { item ->
            MediaItem.Builder().setMediaId(item.id.toString()).setUri(item.uri).build()
        }
        player.setMediaItems(mediaItems, index, 0L)
        player.shuffleModeEnabled = shuffleEnabled
        player.repeatMode = repeatMode
        player.prepare()
        player.play()
        showLyrics = false
    }

    val visibleTracks = tracks.filter {
        (!showFavoritesOnly || favorites.contains(it.id)) &&
            (it.title.contains(searchText, true) || it.artist.contains(searchText, true))
    }

    MaterialTheme(colorScheme = darkColorScheme()) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Universal Music Player", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = { showFavoritesOnly = !showFavoritesOnly; showLyrics = false }) {
                            Icon(if (showFavoritesOnly) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorites")
                        }
                        TextButton(onClick = { showLyrics = !showLyrics }) {
                            Icon(Icons.Filled.Lyrics, null)
                            Spacer(Modifier.width(4.dp))
                            Text(if (showLyrics) "Songs" else "Lyrics")
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                if (showLyrics) {
                    LyricsScreen(
                        track = selectedTrack,
                        original = originalLyrics,
                        translated = translatedLyrics,
                        loading = lyricsLoading,
                        status = lyricsStatus,
                        displayMode = lyricsDisplayMode,
                        onDisplayModeChange = { lyricsDisplayMode = it },
                        showTranslation = showTranslation,
                        onToggleTranslation = { showTranslation = it }
                    )
                } else {
                    Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                        Text(if (showFavoritesOnly) "Your favourites" else "Your music", style = MaterialTheme.typography.titleLarge)
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = {
                            if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
                            else permissionLauncher.launch(permission)
                        }) { Text("Rescan") }
                    }
                    OutlinedTextField(
                        value = searchText,
                        onValueChange = { searchText = it },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        label = { Text("Search songs or artists") }
                    )
                    Spacer(Modifier.height(8.dp))
                    if (visibleTracks.isEmpty()) {
                        Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                            Text(if (tracks.isEmpty()) "No music found. Allow audio access, add music to your phone, then tap Rescan." else "No matching songs found.", textAlign = TextAlign.Center)
                        }
                    } else {
                        LazyColumn(Modifier.weight(1f)) {
                            items(visibleTracks, key = { it.id }) { track ->
                                ListItem(
                                    leadingContent = { Icon(Icons.Filled.MusicNote, null) },
                                    headlineContent = { Text(track.title, maxLines = 1) },
                                    supportingContent = { Text(track.artist, maxLines = 1) },
                                    trailingContent = {
                                        IconButton(onClick = {
                                            if (favorites.contains(track.id)) favorites.remove(track.id) else favorites.add(track.id)
                                        }) { Icon(if (favorites.contains(track.id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favourite") }
                                    },
                                    modifier = Modifier.clickable { playTrack(track) }
                                )
                                HorizontalDivider()
                            }
                        }
                    }
                }

                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(selectedTrack?.title ?: "Nothing playing", style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(selectedTrack?.artist ?: "Choose a song from your library", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shuffleEnabled = !shuffleEnabled; player.shuffleModeEnabled = shuffleEnabled }) {
                        Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToPreviousMediaItem() }) {
                        Icon(Icons.Filled.SkipPrevious, "Previous")
                    }
                    FilledIconButton(onClick = {
                        if (player.isPlaying) player.pause() else if (selectedTrack != null) player.play()
                    }, enabled = selectedTrack != null) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (isPlaying) "Pause" else "Play")
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToNextMediaItem() }) {
                        Icon(Icons.Filled.SkipNext, "Next")
                    }
                    IconButton(onClick = {
                        repeatMode = when (repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }
                        player.repeatMode = repeatMode
                    }) {
                        Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat", tint = if (repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(
                    when (repeatMode) {
                        Player.REPEAT_MODE_ONE -> "Repeat one"
                        Player.REPEAT_MODE_ALL -> "Repeat all"
                        else -> "Repeat off"
                    },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
                    textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
private fun LyricsScreen(
    track: MusicTrack?,
    original: String,
    translated: String,
    loading: Boolean,
    status: String,
    displayMode: Int,
    onDisplayModeChange: (Int) -> Unit,
    showTranslation: Boolean,
    onToggleTranslation: (Boolean) -> Unit
) {
    Column(Modifier.fillMaxSize()) {
        Text("Automatic lyrics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(track?.let { "${it.title} • ${it.artist}" } ?: "No song selected", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        if (loading) {
            LinearProgressIndicator(Modifier.fillMaxWidth())
            Spacer(Modifier.height(12.dp))
        }
        if (original.isNotBlank()) {
            Text("Lyrics display", fontWeight = FontWeight.SemiBold)
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(selected = displayMode == 0, onClick = { onDisplayModeChange(0) }, shape = SegmentedButtonDefaults.itemShape(0, 3)) { Text("Both") }
                SegmentedButton(selected = displayMode == 1, onClick = { onDisplayModeChange(1) }, shape = SegmentedButtonDefaults.itemShape(1, 3)) { Text("Translation") }
                SegmentedButton(selected = displayMode == 2, onClick = { onDisplayModeChange(2) }, shape = SegmentedButtonDefaults.itemShape(2, 3)) { Text("Toggle") }
            }
            Spacer(Modifier.height(8.dp))
            if (displayMode == 2) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lyrics language", fontWeight = FontWeight.SemiBold)
                    Spacer(Modifier.weight(1f))
                    Text(if (showTranslation) "Translation" else "Original", color = MaterialTheme.colorScheme.primary)
                    Switch(checked = showTranslation, onCheckedChange = onToggleTranslation, enabled = translated.isNotBlank())
                }
            }
            LazyColumn(Modifier.weight(1f).fillMaxWidth()) {
                item {
                    when (displayMode) {
                        0 -> Column(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
                            Text("Original lyrics", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            Text(original, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), style = MaterialTheme.typography.bodyLarge)
                            HorizontalDivider(Modifier.padding(vertical = 8.dp))
                            Text("Tamil / English translation", style = MaterialTheme.typography.titleMedium, color = MaterialTheme.colorScheme.primary)
                            Text(translated.ifBlank { "Translation is not available for this song yet." }, modifier = Modifier.fillMaxWidth().padding(vertical = 8.dp), style = MaterialTheme.typography.bodyLarge)
                        }
                        1 -> Text(
                            translated.ifBlank { "Translation is not available for this song yet." },
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                        else -> Text(
                            if (showTranslation && translated.isNotBlank()) translated else original,
                            modifier = Modifier.fillMaxWidth().padding(vertical = 12.dp),
                            style = MaterialTheme.typography.bodyLarge
                        )
                    }
                }
            }
            if (translated.isBlank()) Text("Translation is not available for this song yet.", style = MaterialTheme.typography.bodySmall)
        } else {
            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                Text(status, textAlign = TextAlign.Center)
            }
        }
        if (status.isNotBlank() && original.isNotBlank()) Text(status, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Text("Lyrics and translations are fetched online when available. Song matching and translation quality may vary.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
