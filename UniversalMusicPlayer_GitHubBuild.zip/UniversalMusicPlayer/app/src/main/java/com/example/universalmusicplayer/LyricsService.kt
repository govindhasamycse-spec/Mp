package com.example.universalmusicplayer

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Online LRCLIB lookup with timestamp preservation and best-effort Tamil/English translation. */
data class LyricsResult(
    val original: String,
    val translation: String,
    val syncedLyrics: String,
    val message: String
)

object LyricsService {
    fun fetchLyricsAndTranslation(title: String, artist: String): LyricsResult {
        val found = findLyrics(title, artist)
            ?: return LyricsResult("", "", "", "No matching lyrics were found online for this song.")
        val original = found.plain.ifBlank { found.synced.lines().joinToString("\n") { line ->
            line.replace(Regex("^\\[(\\d{2}):(\\d{2})(?:\\.(\\d{1,3}))?]"), "").trim()
        } }
        val sourceLanguage = if (containsTamil(original)) "ta" else "en"
        val targetLanguage = if (sourceLanguage == "ta") "en" else "ta"
        val translation = try { translateText(original, sourceLanguage, targetLanguage) } catch (_: Exception) { "" }
        val label = if (sourceLanguage == "ta") "Tamil" else "English / other"
        val message = when {
            found.synced.isNotBlank() -> if (translation.isBlank()) "$label timed lyrics found. Translation is temporarily unavailable." else "$label timed lyrics found. Translation is ready."
            translation.isBlank() -> "$label lyrics found, but timed lyrics are unavailable and translation could not be loaded."
            else -> "$label lyrics found. Translation is ready. Timed lyrics are unavailable for this song."
        }
        return LyricsResult(original, translation, found.synced, message)
    }

    private data class FoundLyrics(val plain: String, val synced: String)

    private fun findLyrics(title: String, artist: String): FoundLyrics? {
        val exactUrl = "https://lrclib.net/api/get?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val exact = runCatching { requestJson(exactUrl) }.getOrNull()
        if (exact != null) {
            val plain = exact.optString("plainLyrics").trim()
            val synced = exact.optString("syncedLyrics").trim()
            if (plain.isNotBlank() || synced.isNotBlank()) return FoundLyrics(plain, synced)
        }
        val searchUrl = "https://lrclib.net/api/search?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val results = runCatching { requestJsonArray(searchUrl) }.getOrNull() ?: return null
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val plain = item.optString("plainLyrics").trim()
            val synced = item.optString("syncedLyrics").trim()
            if (plain.isNotBlank() || synced.isNotBlank()) return FoundLyrics(plain, synced)
        }
        return null
    }

    private fun translateText(text: String, from: String, to: String): String {
        // Translate manageable chunks while preserving existing line breaks where possible.
        return text.chunked(430).map { translateChunk(it, from, to) }.joinToString("").trim()
    }

    private fun translateChunk(value: String, from: String, to: String): String {
        val url = "https://api.mymemory.translated.net/get?q=${enc(value)}&langpair=$from|$to"
        return requestJson(url).optJSONObject("responseData")?.optString("translatedText")
            ?.takeIf { it.isNotBlank() } ?: value
    }

    private fun containsTamil(text: String): Boolean = text.any { it.code in 0x0B80..0x0BFF }
    private fun clean(value: String): String = value.replace(Regex("\\s*\\([^)]*\\)\\s*$"), "")
        .replace(Regex("\\s*\\[[^]]*]\\s*$"), "").trim()
    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun requestJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.2 (Android)")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally { connection.disconnect() }
    }

    private fun requestJsonArray(url: String): org.json.JSONArray {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.2 (Android)")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return org.json.JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
        } finally { connection.disconnect() }
    }
}
