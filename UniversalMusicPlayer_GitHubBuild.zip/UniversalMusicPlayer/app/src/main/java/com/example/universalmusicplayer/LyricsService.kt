package com.example.universalmusicplayer

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URLEncoder
import java.net.URL

/** Online lyrics lookup (LRCLIB) plus best-effort Tamil/English translation (MyMemory). */
data class LyricsResult(val original: String, val translation: String, val message: String)

object LyricsService {
    fun fetchLyricsAndTranslation(title: String, artist: String): LyricsResult {
        val lyrics = findLyrics(title, artist)
            ?: return LyricsResult("", "", "No matching lyrics were found online for this song.")
        val sourceLanguage = if (containsTamil(lyrics)) "ta" else "en"
        val targetLanguage = if (sourceLanguage == "ta") "en" else "ta"
        val translation = try {
            translateText(lyrics, sourceLanguage, targetLanguage)
        } catch (_: Exception) {
            ""
        }
        val languageLabel = if (sourceLanguage == "ta") "Tamil" else "English / other"
        val message = if (translation.isBlank()) {
            "$languageLabel lyrics found. Translation is temporarily unavailable."
        } else {
            "$languageLabel lyrics found. Translation is ready."
        }
        return LyricsResult(lyrics, translation, message)
    }

    private fun findLyrics(title: String, artist: String): String? {
        val exactUrl = "https://lrclib.net/api/get?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val exact = runCatching { requestJson(exactUrl).optString("plainLyrics").trim() }.getOrNull()
        if (!exact.isNullOrBlank()) return exact

        val searchUrl = "https://lrclib.net/api/search?track_name=${enc(clean(title))}&artist_name=${enc(clean(artist))}"
        val results = runCatching { requestJsonArray(searchUrl) }.getOrNull() ?: return null
        for (i in 0 until results.length()) {
            val item = results.optJSONObject(i) ?: continue
            val plain = item.optString("plainLyrics").trim()
            val synced = item.optString("syncedLyrics").trim()
            val candidate = if (plain.isNotBlank()) plain else synced
            if (candidate.isNotBlank()) return candidate
        }
        return null
    }

    private fun translateText(text: String, from: String, to: String): String {
        // MyMemory accepts relatively small text blocks; retain line breaks between chunks.
        val chunks = text.chunked(430)
        return chunks.map { chunk -> translateChunk(chunk, from, to) }
            .joinToString("").takeIf { it.isNotBlank() } ?: ""
    }

    private fun translateChunk(line: String, from: String, to: String): String {
        val url = "https://api.mymemory.translated.net/get?q=${enc(line)}&langpair=$from|$to"
        val json = requestJson(url)
        return json.optJSONObject("responseData")?.optString("translatedText")
            ?.takeIf { it.isNotBlank() } ?: line
    }

    private fun containsTamil(text: String): Boolean = text.any { it.code in 0x0B80..0x0BFF }

    private fun clean(value: String): String = value
        .replace(Regex("\\s*\\([^)]*\\)\\s*$"), "")
        .replace(Regex("\\s*\\[[^]]*]\\s*$"), "")
        .trim()

    private fun enc(value: String): String = URLEncoder.encode(value, "UTF-8")

    private fun requestJson(url: String): JSONObject {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.0 (Android)")
            connection.setRequestProperty("Accept", "application/json")
            val code = connection.responseCode
            val stream = if (code in 200..299) connection.inputStream else connection.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return JSONObject(body)
        } finally {
            connection.disconnect()
        }
    }

    private fun requestJsonArray(url: String): org.json.JSONArray {
        val connection = URL(url).openConnection() as HttpURLConnection
        try {
            connection.requestMethod = "GET"
            connection.connectTimeout = 12000
            connection.readTimeout = 15000
            connection.setRequestProperty("User-Agent", "UniversalMusicPlayer/2.0 (Android)")
            val code = connection.responseCode
            if (code !in 200..299) throw IllegalStateException("HTTP $code")
            return org.json.JSONArray(connection.inputStream.bufferedReader().use { it.readText() })
        } finally {
            connection.disconnect()
        }
    }
}
