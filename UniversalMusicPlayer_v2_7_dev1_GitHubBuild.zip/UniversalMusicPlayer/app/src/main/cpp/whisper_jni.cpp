#include <jni.h>
#include <string>
#include <sstream>
#include <iomanip>
#include "whisper.h"

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_universalmusicplayer_WhisperNative_nativeTranscribe(
        JNIEnv *env, jobject /* thiz */, jstring model_path, jfloatArray audio, jstring language) {
    const char *model_chars = env->GetStringUTFChars(model_path, nullptr);
    const char *language_chars = env->GetStringUTFChars(language, nullptr);
    const jsize audio_length = env->GetArrayLength(audio);
    jfloat *audio_samples = env->GetFloatArrayElements(audio, nullptr);

    whisper_context *ctx = whisper_init_from_file(model_chars);
    env->ReleaseStringUTFChars(model_path, model_chars);
    if (ctx == nullptr) {
        env->ReleaseStringUTFChars(language, language_chars);
        env->ReleaseFloatArrayElements(audio, audio_samples, JNI_ABORT);
        return env->NewStringUTF("");
    }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = language_chars;
    params.n_threads = 4;
    params.no_context = true;
    params.single_segment = false;

    const int result = whisper_full(ctx, params, audio_samples, audio_length);
    env->ReleaseStringUTFChars(language, language_chars);
    env->ReleaseFloatArrayElements(audio, audio_samples, JNI_ABORT);

    std::ostringstream output;
    if (result == 0) {
        const int count = whisper_full_n_segments(ctx);
        for (int i = 0; i < count; ++i) {
            const int64_t start = whisper_full_get_segment_t0(ctx, i) * 10; // whisper timestamps are 10 ms units
            const char *text = whisper_full_get_segment_text(ctx, i);
            if (text == nullptr || std::string(text).empty()) continue;
            const int64_t minutes = start / 60000;
            const int64_t seconds = (start / 1000) % 60;
            const int64_t centiseconds = (start % 1000) / 10;
            output << '[' << std::setfill('0') << std::setw(2) << minutes << ':'
                   << std::setw(2) << seconds << '.' << std::setw(2) << centiseconds
                   << ']' << text << '\n';
        }
    }
    whisper_free(ctx);
    return env->NewStringUTF(output.str().c_str());
}
