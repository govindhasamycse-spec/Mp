package com.example.universalmusicplayer

import android.content.Context
import java.io.File

/** JNI bridge to whisper.cpp. The multilingual model is packaged in the APK assets. */
object WhisperNative {
    init { System.loadLibrary("whisper_jni") }

    private external fun nativeTranscribe(modelPath: String, audio16kMono: FloatArray, language: String): String

    fun transcribeFromAssets(context: Context, samples: FloatArray): String {
        require(samples.isNotEmpty()) { "No decoded audio was available." }
        val model = File(context.filesDir, "ggml-tiny.bin")
        if (!model.exists() || model.length() < 70_000_000L) {
            context.assets.open("models/ggml-tiny.bin").use { input ->
                model.outputStream().use { output -> input.copyTo(output) }
            }
        }
        return nativeTranscribe(model.absolutePath, samples, "auto")
    }
}
