package com.example.universalmusicplayer

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

/** Persistent local listening data. No account or cloud sync is used. */
object LibraryStore {
    private const val PREFS = "ump_library_v27"
    private const val FAVORITES = "favorite_ids"
    private const val HISTORY = "recent_ids"
    private const val COUNTS = "play_counts"

    fun favorites(context: Context): Set<Long> = readLongs(context, FAVORITES).toSet()
    fun recent(context: Context): List<Long> = readLongs(context, HISTORY)

    fun toggleFavorite(context: Context, id: Long): Set<Long> {
        val values = favorites(context).toMutableSet()
        if (!values.add(id)) values.remove(id)
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putString(FAVORITES, JSONArray(values.toList()).toString()).apply()
        return values
    }

    fun recordPlay(context: Context, id: Long) {
        val prefs = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        val recent = readLongs(context, HISTORY).toMutableList()
        recent.remove(id)
        recent.add(0, id)
        val counts = runCatching { JSONObject(prefs.getString(COUNTS, "{}") ?: "{}") }
            .getOrDefault(JSONObject())
        val key = id.toString()
        counts.put(key, counts.optInt(key, 0) + 1)
        prefs.edit()
            .putString(HISTORY, JSONArray(recent.take(100)).toString())
            .putString(COUNTS, counts.toString())
            .apply()
    }

    fun mostPlayed(context: Context): List<Long> {
        val counts = runCatching {
            JSONObject(context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(COUNTS, "{}") ?: "{}")
        }.getOrDefault(JSONObject())
        val ids = mutableListOf<Pair<Long, Int>>()
        val keys = counts.keys()
        while (keys.hasNext()) {
            val key = keys.next()
            key.toLongOrNull()?.let { ids += it to counts.optInt(key, 0) }
        }
        return ids.sortedByDescending { it.second }.take(50).map { it.first }
    }

    private fun readLongs(context: Context, key: String): List<Long> = runCatching {
        val raw = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString(key, "[]") ?: "[]"
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { array.optLong(it).takeIf { value -> value > 0L } }
    }.getOrDefault(emptyList())
}
