package com.example.universalmusicplayer

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer

/** Controls the Android device DSP for the active ExoPlayer audio session. */
class AudioEffectsController(sessionId: Int) {
    private val equalizer = Equalizer(0, sessionId)
    private val bassBoost = BassBoost(0, sessionId)

    val bandCount: Int
        get() = minOf(10, equalizer.numberOfBands.toInt())

    val bassStrength: Int
        get() = if (bassBoost.enabled) bassBoost.roundedStrength.toInt() else 0

    init {
        equalizer.enabled = true
        bassBoost.enabled = true
    }

    fun getBandLevel(index: Int): Int =
        equalizer.getBandLevel(index.toShort()).toInt()

    fun setBandLevel(index: Int, levelHundredthDb: Int) {
        val range = equalizer.bandLevelRange
        val bounded = levelHundredthDb.coerceIn(range[0].toInt(), range[1].toInt())
        equalizer.setBandLevel(index.toShort(), bounded.toShort())
    }

    fun bandLabel(index: Int): String {
        val hz = equalizer.getCenterFreq(index.toShort()) / 1000
        return if (hz >= 1000) "${hz / 1000f} kHz" else "$hz Hz"
    }

    fun setBassStrength(strength: Int) {
        bassBoost.setStrength(strength.coerceIn(0, 1000).toShort())
    }

    fun release() {
        runCatching { equalizer.release() }
        runCatching { bassBoost.release() }
    }
}
