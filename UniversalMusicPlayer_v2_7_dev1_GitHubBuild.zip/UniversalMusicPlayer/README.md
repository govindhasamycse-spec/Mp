# Universal Music Player v2.5

Android local music player built with Kotlin, Jetpack Compose, Media3 ExoPlayer and whisper.cpp.

## Features
- Local music library, search, favourites, shuffle and repeat
- Songs and live lyrics on the same screen; equalizer remains a separate screen
- Automatic LRCLIB online lyrics lookup with local lyrics/translation cache
- Timestamped LRC line highlighting and automatic scrolling when timing is available
- Original / translation / both lyrics display modes
- Offline AI lyric transcription using the multilingual Whisper Tiny model and whisper.cpp
- AI model is included in the installed APK; no model download is needed after installation
- AI transcription is a manual fallback shown when online/cache lookup has no lyrics
- Device audio-session equalizer and bass boost (hardware support varies)
- Animated playback visualizer and voice search

## Bundled AI model
The GitHub Actions build downloads the official `ggml-tiny.bin` multilingual model from the whisper.cpp Hugging Face repository, verifies its SHA-256 checksum, and packages it into `app/src/main/assets/models/` before building the APK. Android users receive the model inside the APK and can transcribe offline after installation. The source ZIP does not carry the 77.7 MB model binary; the build workflow fetches it automatically and embeds it in the APK.

The app currently builds the native Whisper runtime for `arm64-v8a`. The model is approximately 77.7 MB, so the APK is substantially larger than v2.4. The app decodes a local audio track to 16 kHz mono PCM and runs Whisper on-device. Generated words and timestamps can be inaccurate for singing, backing vocals, fast lyrics, or noisy mixes; review AI-generated lyrics before relying on them. AI transcription is limited to tracks up to 10 minutes to reduce memory pressure.

## Important notes
- AI transcription is a fallback, not guaranteed lyric recognition. Whisper is a speech-recognition model and may struggle with music vocals.
- Whisper-generated segment timestamps are line-level estimates, not word-level karaoke timing.
- Translation after AI transcription uses the online translation service when internet is available. Original AI transcription itself works offline.
- The visualizer is an animated playback indicator, not an audio-frequency analyzer.
- Voice search depends on a speech-recognition service installed on the phone.
- Equalizer bands and bass boost depend on the device audio engine.

## Build
Push this project to the `main` branch or run the workflow manually from GitHub Actions. The workflow installs Android NDK/CMake, downloads and verifies the model, compiles whisper.cpp for ARM64, and uploads `app-debug.apk` as the `UniversalMusicPlayer-v2.5-debug-apk` artifact.

## v2.7 development baseline (dev1)

This development snapshot adds persistent local favourites, a local recently-played history, a most-played smart list, and a selectable sleep timer (15/30/45/60/90 minutes). Listening data is stored locally with SharedPreferences; it is not uploaded to a server.

This is an incremental development build, **not a completed v2.7 release**. Smart audio fingerprint identification, true audio-reactive visualization, complete advanced audio controls, automatic embedded/local lyrics discovery, Whisper model packaging verification, and on-device Tamil/English transcription testing remain outstanding. The visualizer currently animates decoratively; it is not yet driven by live frequency data.

The Android GitHub Actions workflow builds a debug APK and downloads/verifies the Whisper Tiny multilingual model through the Gradle `preBuild` task. A successful build and APK inspection are still required before model packaging can be claimed as verified.
