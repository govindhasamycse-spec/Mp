import java.net.URL
import java.security.MessageDigest

plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
    id("org.jetbrains.kotlin.plugin.compose")
}

val downloadWhisperModel by tasks.registering {
    val modelFile = layout.projectDirectory.file("src/main/assets/models/ggml-tiny.bin")
    outputs.file(modelFile)
    doLast {
        val target = modelFile.asFile
        target.parentFile.mkdirs()
        val expectedSize = 77_691_713L
        val expectedSha256 = "be07e048e1e599ad46341c8d2a135645097a538221678b7acdd1b1919c6e1b21"
        if (!target.exists() || target.length() != expectedSize) {
            val partial = File(target.parentFile, target.name + ".part")
            URL("https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-tiny.bin")
                .openConnection().apply {
                    connectTimeout = 30_000
                    readTimeout = 120_000
                }.getInputStream().use { input -> partial.outputStream().use { output -> input.copyTo(output) } }
            check(partial.length() == expectedSize) { "Whisper Tiny model download has an unexpected size." }
            if (target.exists()) target.delete()
            check(partial.renameTo(target)) { "Could not move downloaded Whisper model into assets." }
        }
        val digest = MessageDigest.getInstance("SHA-256").digest(target.readBytes())
            .joinToString("") { "%02x".format(it) }
        check(digest == expectedSha256) { "Whisper model checksum did not match; refusing to package it." }
        println("Verified bundled Whisper Tiny multilingual model (${target.length()} bytes).")
    }
}

tasks.named("preBuild").configure { dependsOn(downloadWhisperModel) }

android {
    namespace = "com.example.universalmusicplayer"
    compileSdk = 35
    ndkVersion = "27.2.12479018"

    defaultConfig {
        applicationId = "com.example.universalmusicplayer"
        minSdk = 23
        targetSdk = 35
        versionCode = 5
        versionName = "2.5"
        ndk { abiFilters += listOf("arm64-v8a") }
        externalNativeBuild {
            cmake { cppFlags += listOf("-std=c++17") }
        }
    }

    androidResources { noCompress += "bin" }

    externalNativeBuild {
        cmake {
            path = file("src/main/cpp/CMakeLists.txt")
            version = "3.22.1"
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-compose:1.10.0")
    implementation(platform("androidx.compose:compose-bom:2024.12.01"))
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.media3:media3-exoplayer:1.5.1")
    implementation("androidx.compose.material:material-icons-extended")
    debugImplementation("androidx.compose.ui:ui-tooling")
}
