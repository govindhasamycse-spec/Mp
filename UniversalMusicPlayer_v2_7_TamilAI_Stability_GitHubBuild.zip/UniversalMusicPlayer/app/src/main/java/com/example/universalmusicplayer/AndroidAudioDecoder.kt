package com.example.universalmusicplayer

import android.content.Context
import android.media.AudioFormat
import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import android.net.Uri
import java.io.BufferedOutputStream
import java.io.DataOutputStream
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder
import kotlin.math.floor

/**
 * Streams decoded mono PCM to a temporary file instead of retaining a whole song
 * in boxed Float objects. Whisper reads this file in small windows.
 */
object AndroidAudioDecoder {
    data class DecodedPcm(val file: File, val sampleRate: Int, val sampleCount: Long)

    fun decodeToFloatFile(context: Context, uri: Uri): DecodedPcm {
        val pcmFile = File.createTempFile("whisper_audio_", ".f32", context.cacheDir)
        val extractor = MediaExtractor()
        var codec: MediaCodec? = null
        var writtenSamples = 0L
        try {
            extractor.setDataSource(context, uri, null)
            var audioTrack = -1
            var inputFormat: MediaFormat? = null
            for (i in 0 until extractor.trackCount) {
                val format = extractor.getTrackFormat(i)
                val mime = format.getString(MediaFormat.KEY_MIME) ?: continue
                if (mime.startsWith("audio/")) { audioTrack = i; inputFormat = format; break }
            }
            require(audioTrack >= 0 && inputFormat != null) { "No decodable audio track found." }
            extractor.selectTrack(audioTrack)
            val mime = inputFormat.getString(MediaFormat.KEY_MIME)!!
            codec = MediaCodec.createDecoderByType(mime)
            codec.configure(inputFormat, null, null, 0)
            codec.start()

            var sampleRate = inputFormat.getInteger(MediaFormat.KEY_SAMPLE_RATE)
            var channels = inputFormat.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
            var outputEncoding = AudioFormat.ENCODING_PCM_16BIT
            var inputDone = false
            var outputDone = false
            val info = MediaCodec.BufferInfo()

            DataOutputStream(BufferedOutputStream(FileOutputStream(pcmFile), 256 * 1024)).use { output ->
                while (!outputDone) {
                    if (!inputDone) {
                        val inputIndex = codec.dequeueInputBuffer(10_000)
                        if (inputIndex >= 0) {
                            val inputBuffer = codec.getInputBuffer(inputIndex)!!
                            val sampleSize = extractor.readSampleData(inputBuffer, 0)
                            if (sampleSize < 0) {
                                codec.queueInputBuffer(inputIndex, 0, 0, 0L, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                                inputDone = true
                            } else {
                                codec.queueInputBuffer(inputIndex, 0, sampleSize, extractor.sampleTime, 0)
                                extractor.advance()
                            }
                        }
                    }

                    when (val outputIndex = codec.dequeueOutputBuffer(info, 10_000)) {
                        MediaCodec.INFO_OUTPUT_FORMAT_CHANGED -> {
                            val format = codec.outputFormat
                            if (format.containsKey(MediaFormat.KEY_SAMPLE_RATE)) sampleRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                            if (format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                            if (format.containsKey(MediaFormat.KEY_PCM_ENCODING)) outputEncoding = format.getInteger(MediaFormat.KEY_PCM_ENCODING)
                        }
                        MediaCodec.INFO_TRY_AGAIN_LATER -> Unit
                        else -> if (outputIndex >= 0) {
                            try {
                                val buffer = codec.getOutputBuffer(outputIndex)
                                if (buffer != null && info.size > 0) {
                                    buffer.position(info.offset)
                                    buffer.limit(info.offset + info.size)
                                    val data = buffer.slice().order(ByteOrder.LITTLE_ENDIAN)
                                    when (outputEncoding) {
                                        AudioFormat.ENCODING_PCM_16BIT -> while (data.remaining() >= 2 * channels) {
                                            var sum = 0f
                                            repeat(channels) { sum += data.short / 32768f }
                                            output.writeFloat(sum / channels)
                                            writtenSamples++
                                        }
                                        AudioFormat.ENCODING_PCM_FLOAT -> while (data.remaining() >= 4 * channels) {
                                            var sum = 0f
                                            repeat(channels) { sum += data.float }
                                            output.writeFloat(sum / channels)
                                            writtenSamples++
                                        }
                                        else -> error("Unsupported decoded PCM format: $outputEncoding")
                                    }
                                    require(writtenSamples.toDouble() / sampleRate <= 600.0) {
                                        "Offline AI is limited to 10-minute audio clips."
                                    }
                                }
                                outputDone = (info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0
                            } finally {
                                codec.releaseOutputBuffer(outputIndex, false)
                            }
                        }
                    }
                }
            }
            require(writtenSamples > 0) { "The audio decoder returned no samples." }
            return DecodedPcm(pcmFile, sampleRate, writtenSamples)
        } catch (t: Throwable) {
            pcmFile.delete()
            throw t
        } finally {
            runCatching { codec?.stop() }
            runCatching { codec?.release() }
            runCatching { extractor.release() }
        }
    }

    /** Convert one bounded mono window to Whisper's required 16 kHz input. */
    fun resampleWindow(input: FloatArray, fromRate: Int, toRate: Int = 16_000): FloatArray {
        if (fromRate == toRate) return input
        require(input.isNotEmpty() && fromRate > 0)
        val outputSize = floor(input.size.toDouble() * toRate / fromRate).toInt().coerceAtLeast(1)
        return FloatArray(outputSize) { index ->
            val source = index.toDouble() * fromRate / toRate
            val left = source.toInt().coerceIn(0, input.lastIndex)
            val right = (left + 1).coerceAtMost(input.lastIndex)
            val fraction = (source - left).toFloat()
            input[left] * (1f - fraction) + input[right] * fraction
        }
    }
}
