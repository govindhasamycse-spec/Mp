#include <jni.h>
#include <cstdint>
#include <string>
#include <sstream>
#include <iomanip>
#include "whisper.h"

static whisper_context *as_context(jlong handle) {
    return reinterpret_cast<whisper_context *>(static_cast<intptr_t>(handle));
}

extern "C"
JNIEXPORT jlong JNICALL
Java_com_example_universalmusicplayer_WhisperNative_nativeCreateContext(
        JNIEnv *env, jobject, jstring model_path) {
    if (model_path == nullptr) return 0;
    const char *path = env->GetStringUTFChars(model_path, nullptr);
    if (path == nullptr) return 0;
    whisper_context *ctx = whisper_init_from_file(path);
    env->ReleaseStringUTFChars(model_path, path);
    return static_cast<jlong>(reinterpret_cast<intptr_t>(ctx));
}

extern "C"
JNIEXPORT jstring JNICALL
Java_com_example_universalmusicplayer_WhisperNative_nativeTranscribeChunk(
        JNIEnv *env, jobject, jlong handle, jfloatArray audio, jstring language, jlong offset_ms) {
    whisper_context *ctx = as_context(handle);
    if (ctx == nullptr || audio == nullptr || language == nullptr) return env->NewStringUTF("");
    const char *language_chars = env->GetStringUTFChars(language, nullptr);
    if (language_chars == nullptr) return env->NewStringUTF("");
    const jsize audio_length = env->GetArrayLength(audio);
    jfloat *samples = env->GetFloatArrayElements(audio, nullptr);
    if (samples == nullptr) {
        env->ReleaseStringUTFChars(language, language_chars);
        return env->NewStringUTF("");
    }

    whisper_full_params params = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    params.print_realtime = false;
    params.print_progress = false;
    params.print_timestamps = false;
    params.print_special = false;
    params.translate = false;
    params.language = language_chars;
    params.n_threads = 2;
    params.no_context = true;
    params.single_segment = false;
    params.no_speech_thold = 0.65f;

    const int status = whisper_full(ctx, params, samples, audio_length);
    env->ReleaseStringUTFChars(language, language_chars);
    env->ReleaseFloatArrayElements(audio, samples, JNI_ABORT);

    std::ostringstream output;
    if (status == 0) {
        const int count = whisper_full_n_segments(ctx);
        for (int i = 0; i < count; ++i) {
            const int64_t start_ms = offset_ms + whisper_full_get_segment_t0(ctx, i) * 10;
            const char *text = whisper_full_get_segment_text(ctx, i);
            if (text == nullptr || std::string(text).empty()) continue;
            const int64_t minutes = start_ms / 60000;
            const int64_t seconds = (start_ms / 1000) % 60;
            const int64_t centiseconds = (start_ms % 1000) / 10;
            output << '[' << std::setfill('0') << std::setw(2) << minutes << ':'
                   << std::setw(2) << seconds << '.' << std::setw(2) << centiseconds
                   << ']' << text << '\n';
        }
    }
    return env->NewStringUTF(output.str().c_str());
}

extern "C"
JNIEXPORT void JNICALL
Java_com_example_universalmusicplayer_WhisperNative_nativeFreeContext(
        JNIEnv *, jobject, jlong handle) {
    whisper_context *ctx = as_context(handle);
    if (ctx != nullptr) whisper_free(ctx);
}
