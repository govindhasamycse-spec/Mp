package com.example.universalmusicplayer

import android.content.Intent
import android.net.Uri
import android.Manifest
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.speech.RecognizerIntent
import androidx.activity.ComponentActivity
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Equalizer
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lyrics
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Timer
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Repeat
import androidx.compose.material.icons.filled.RepeatOne
import androidx.compose.material.icons.filled.Shuffle
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.exoplayer.ExoPlayer
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import kotlinx.coroutines.launch
import kotlin.math.PI
import kotlin.math.sin

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { MusicPlayerApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MusicPlayerApp() {
    val context = LocalContext.current
    val player = remember { ExoPlayer.Builder(context).build() }
    var tracks by remember { mutableStateOf(emptyList<MusicTrack>()) }
    var selectedTrack by remember { mutableStateOf<MusicTrack?>(null) }
    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var shuffleEnabled by remember { mutableStateOf(false) }
    var repeatMode by remember { mutableIntStateOf(Player.REPEAT_MODE_OFF) }
    var showEqualizer by remember { mutableStateOf(false) }
    var originalLyrics by remember { mutableStateOf("") }
    var translatedLyrics by remember { mutableStateOf("") }
    var syncedLyrics by remember { mutableStateOf("") }
    var lyricsStatus by remember { mutableStateOf("Choose a song to find lyrics automatically.") }
    var lyricsLoading by remember { mutableStateOf(false) }
    var lyricsDisplayMode by remember { mutableIntStateOf(2) }
    var showTranslation by remember { mutableStateOf(false) }
    var searchText by remember { mutableStateOf("") }
    val favorites = remember { mutableStateListOf<Long>().apply { addAll(LibraryStore.favorites(context)) } }
    var showFavoritesOnly by remember { mutableStateOf(false) }
    var showHistoryOnly by remember { mutableStateOf(false) }
    var showMostPlayedOnly by remember { mutableStateOf(false) }
    var recentIds by remember { mutableStateOf(LibraryStore.recent(context)) }
    var mostPlayedIds by remember { mutableStateOf(LibraryStore.mostPlayed(context)) }
    var showSleepTimer by remember { mutableStateOf(false) }
    var sleepTimerMinutes by remember { mutableIntStateOf(0) }
    val latestTracks by rememberUpdatedState(tracks)
    var effectsController by remember { mutableStateOf<AudioEffectsController?>(null) }
    var aiTranscribing by remember { mutableStateOf(false) }
    val scope = rememberCoroutineScope()

    val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
        else Manifest.permission.READ_EXTERNAL_STORAGE
    fun refreshLibrary() { tracks = MusicRepository(context).loadSongs() }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) {
        if (it) refreshLibrary()
    }
    val voiceLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
        val spoken = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
        if (!spoken.isNullOrBlank()) searchText = spoken
    }
    val lyricFileLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val track = selectedTrack
        if (uri != null && track != null) {
            runCatching {
                context.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() }
                    ?: throw IllegalStateException("Could not read the selected lyrics file.")
            }.onSuccess { content ->
                val timed = LyricsParser.parse(content)
                val plain = if (timed.isNotEmpty()) timed.joinToString("\n") { it.text }
                    else content.lines().filter { it.isNotBlank() }.joinToString("\n")
                if (plain.isBlank()) {
                    lyricsStatus = "The selected file does not contain readable lyrics."
                } else {
                    originalLyrics = plain
                    syncedLyrics = if (timed.isNotEmpty()) content else ""
                    translatedLyrics = ""
                    lyricsStatus = "Lyrics imported from your phone and saved for offline playback."
                    LyricsCache.save(context, track.title, track.artist,
                        LyricsResult(originalLyrics, translatedLyrics, lyricsStatus, syncedLyrics))
                }
            }.onFailure { lyricsStatus = "Could not import lyrics: ${it.message ?: "file error"}" }
        }
    }

    DisposableEffect(player) {
        val listener = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onMediaItemTransition(mediaItem: MediaItem?, reason: Int) {
                selectedTrack = latestTracks.firstOrNull { it.id.toString() == mediaItem?.mediaId }
            }
        }
        player.addListener(listener)
        onDispose { player.removeListener(listener); effectsController?.release(); player.release() }
    }

    DisposableEffect(player.audioSessionId) {
        val session = player.audioSessionId
        val controller = if (session != 0) runCatching { AudioEffectsController(session) }.getOrNull() else null
        effectsController = controller
        onDispose { controller?.release(); if (effectsController === controller) effectsController = null }
    }

    LaunchedEffect(Unit) {
        if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
        else permissionLauncher.launch(permission)
    }

    LaunchedEffect(isPlaying, player) {
        while (isPlaying) {
            positionMs = player.currentPosition.coerceAtLeast(0L)
            delay(250)
        }
        positionMs = player.currentPosition.coerceAtLeast(0L)
    }

    // Some devices create the audio session only after playback starts.
    LaunchedEffect(isPlaying, selectedTrack?.id) {
        if (isPlaying && effectsController == null) {
            delay(600)
            val session = player.audioSessionId
            if (session != 0) effectsController = runCatching { AudioEffectsController(session) }.getOrNull()
        }
    }

    LaunchedEffect(selectedTrack?.id) {
        val track = selectedTrack ?: return@LaunchedEffect
        originalLyrics = ""; translatedLyrics = ""; syncedLyrics = ""
        showTranslation = false; lyricsLoading = true
        lyricsStatus = "Searching online for lyrics…"
        try {
            // v2.7 recovery order: online lookup first, then this phone's saved cache.
            val online = withContext(Dispatchers.IO) {
                LyricsService.fetchLyricsAndTranslation(track.title, track.artist)
            }
            if (online.original.isNotBlank()) {
                originalLyrics = online.original; translatedLyrics = online.translation
                syncedLyrics = online.syncedLyrics; lyricsStatus = online.message
                withContext(Dispatchers.IO) { LyricsCache.save(context, track.title, track.artist, online) }
                lyricsStatus += " Saved on this phone for offline playback."
            } else {
                val cached = withContext(Dispatchers.IO) { LyricsCache.get(context, track.title, track.artist) }
                if (cached != null) {
                    originalLyrics = cached.original; translatedLyrics = cached.translation
                    syncedLyrics = cached.syncedLyrics
                    lyricsStatus = "Online lyrics unavailable. Loaded saved lyrics from this phone."
                } else {
                    lyricsStatus = online.message
                }
            }
        } catch (_: Exception) {
            val cached = withContext(Dispatchers.IO) { LyricsCache.get(context, track.title, track.artist) }
            if (cached != null) {
                originalLyrics = cached.original; translatedLyrics = cached.translation
                syncedLyrics = cached.syncedLyrics
                lyricsStatus = "Offline: loaded saved lyrics from this phone."
            } else {
                lyricsStatus = "Online lookup failed and no cached lyrics were found. Import a local LRC/TXT file or try offline AI."
            }
        } finally { lyricsLoading = false }
    }

    fun playTrack(track: MusicTrack) {
        val index = tracks.indexOfFirst { it.id == track.id }
        if (index < 0) return
        selectedTrack = track
        LibraryStore.recordPlay(context, track.id)
        recentIds = LibraryStore.recent(context)
        mostPlayedIds = LibraryStore.mostPlayed(context)
        val items = tracks.map { MediaItem.Builder().setMediaId(it.id.toString()).setUri(it.uri).build() }
        player.setMediaItems(items, index, 0L)
        player.shuffleModeEnabled = shuffleEnabled; player.repeatMode = repeatMode
        player.prepare(); player.play()
        showEqualizer = false
    }

    LaunchedEffect(sleepTimerMinutes) {
        if (sleepTimerMinutes > 0) {
            delay(sleepTimerMinutes * 60_000L)
            player.pause()
            sleepTimerMinutes = 0
        }
    }

    val visibleTracks = tracks.filter {
        (!showFavoritesOnly || favorites.contains(it.id)) &&
            (!showHistoryOnly || recentIds.contains(it.id)) &&
            (!showMostPlayedOnly || mostPlayedIds.contains(it.id)) &&
            (it.title.contains(searchText, true) || it.artist.contains(searchText, true))
    }.let { list ->
        if (showHistoryOnly) list.sortedBy { recentIds.indexOf(it.id).let { index -> if (index < 0) Int.MAX_VALUE else index } }
        else if (showMostPlayedOnly) list.sortedBy { mostPlayedIds.indexOf(it.id).let { index -> if (index < 0) Int.MAX_VALUE else index } }
        else list
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFF8B7CFF),
        secondary = Color(0xFF42D9FF),
        background = Color(0xFF090914),
        surface = Color(0xFF151528)
    )) {
        if (showSleepTimer) {
            AlertDialog(
                onDismissRequest = { showSleepTimer = false },
                title = { Text("Sleep timer") },
                text = {
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(if (sleepTimerMinutes > 0) "Sleep timer is set for $sleepTimerMinutes minutes." else "Pause playback automatically after:")
                        listOf(15, 30, 45, 60, 90).forEach { minutes ->
                            TextButton(onClick = { sleepTimerMinutes = minutes; showSleepTimer = false }, modifier = Modifier.fillMaxWidth()) {
                                Text("$minutes minutes")
                            }
                        }
                        TextButton(onClick = { sleepTimerMinutes = 0; showSleepTimer = false }, modifier = Modifier.fillMaxWidth()) {
                            Text("Cancel timer")
                        }
                    }
                },
                confirmButton = { TextButton(onClick = { showSleepTimer = false }) { Text("Close") } }
            )
        }
        Scaffold(
            topBar = {
                TopAppBar(
                    title = { Text("Universal Music Player", fontWeight = FontWeight.Bold) },
                    actions = {
                        IconButton(onClick = {
                            showFavoritesOnly = !showFavoritesOnly
                            showHistoryOnly = false; showMostPlayedOnly = false; showEqualizer = false
                        }) {
                            Icon(if (showFavoritesOnly) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favorites")
                        }
                        IconButton(onClick = {
                            showHistoryOnly = !showHistoryOnly
                            showFavoritesOnly = false; showMostPlayedOnly = false; showEqualizer = false
                        }) { Icon(Icons.Filled.History, "Recently played") }
                        IconButton(onClick = { showSleepTimer = true }) { Icon(Icons.Filled.Timer, "Sleep timer") }
                        IconButton(onClick = { showEqualizer = !showEqualizer }) {
                            Icon(Icons.Filled.Equalizer, "Equalizer")
                        }
                    }
                )
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 16.dp)) {
                when {
                    showEqualizer -> EqualizerScreen(effectsController)
                    else -> {
                        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                            Text(when { showFavoritesOnly -> "Your favourites"; showHistoryOnly -> "Recently played"; showMostPlayedOnly -> "Most played"; else -> "Your music" }, style = MaterialTheme.typography.titleLarge)
                            Spacer(Modifier.weight(1f))
                            IconButton(onClick = {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Search your music")
                                }
                                runCatching { voiceLauncher.launch(intent) }
                            }) { Icon(Icons.Filled.Mic, "Voice search") }
                            TextButton(onClick = {
                                if (ContextCompat.checkSelfPermission(context, permission) == PackageManager.PERMISSION_GRANTED) refreshLibrary()
                                else permissionLauncher.launch(permission)
                            }) { Text("Rescan") }
                        }
                        OutlinedTextField(value = searchText, onValueChange = { searchText = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search songs or artists") })
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            FilterChip(selected = !showFavoritesOnly && !showHistoryOnly && !showMostPlayedOnly,
                                onClick = { showFavoritesOnly = false; showHistoryOnly = false; showMostPlayedOnly = false }, label = { Text("All") })
                            FilterChip(selected = showMostPlayedOnly, onClick = {
                                showMostPlayedOnly = !showMostPlayedOnly; showFavoritesOnly = false; showHistoryOnly = false
                            }, label = { Text("Most played") })
                            FilterChip(selected = showHistoryOnly, onClick = {
                                showHistoryOnly = !showHistoryOnly; showFavoritesOnly = false; showMostPlayedOnly = false
                            }, label = { Text("Recent") })
                        }
                        Spacer(Modifier.height(4.dp))
                        if (visibleTracks.isEmpty()) {
                            Box(Modifier.weight(1f).fillMaxWidth(), contentAlignment = Alignment.Center) {
                                Text(if (tracks.isEmpty()) "No music found. Allow audio access, add music to your phone, then tap Rescan." else "No matching songs found.", textAlign = TextAlign.Center)
                            }
                        } else {
                            LazyColumn(Modifier.weight(if (selectedTrack == null) 1f else 0.38f).fillMaxWidth()) {
                                itemsIndexed(visibleTracks, key = { _, item -> item.id }) { _, track ->
                                    ListItem(
                                        leadingContent = { Icon(Icons.Filled.MusicNote, null) },
                                        headlineContent = { Text(track.title, maxLines = 1) },
                                        supportingContent = { Text(track.artist, maxLines = 1) },
                                        trailingContent = {
                                            IconButton(onClick = {
                                                val updated = LibraryStore.toggleFavorite(context, track.id)
                                                favorites.clear(); favorites.addAll(updated)
                                            }) { Icon(if (favorites.contains(track.id)) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder, "Favourite") }
                                        },
                                        modifier = Modifier.clickable { playTrack(track) }
                                    )
                                    HorizontalDivider()
                                }
                            }
                        }
                        if (selectedTrack != null) {
                            Spacer(Modifier.height(6.dp))
                            LyricsScreen(
                                track = selectedTrack, original = originalLyrics, translated = translatedLyrics,
                                synced = syncedLyrics, positionMs = positionMs, isPlaying = isPlaying,
                                loading = lyricsLoading, status = lyricsStatus, displayMode = lyricsDisplayMode,
                                onDisplayModeChange = { lyricsDisplayMode = it }, showTranslation = showTranslation,
                                onToggleTranslation = { showTranslation = it },
                                modifier = Modifier.weight(0.62f).fillMaxWidth(),
                                aiTranscribing = aiTranscribing,
                                onImportLyrics = { lyricFileLauncher.launch(arrayOf("text/plain", "application/octet-stream", "text/*")) },
                                onAiTranscribe = { selectedLanguage ->
                                    val track = selectedTrack
                                    if (track != null && !aiTranscribing) {
                                        scope.launch {
                                            aiTranscribing = true
                                            lyricsStatus = "Preparing audio for offline AI transcription…"
                                            try {
                                                val lrc = withContext(Dispatchers.IO) {
                                                    val decoded = AndroidAudioDecoder.decodeToFloatFile(context, track.uri)
                                                    try {
                                                        WhisperNative.transcribeFromAssets(
                                                            context, decoded, selectedLanguage,
                                                            onProgress = { done, total ->
                                                                lyricsStatus = "Offline AI: analysing audio section $done of $total…"
                                                            },
                                                            onStatus = { message -> lyricsStatus = message }
                                                        )
                                                    } finally {
                                                        decoded.file.delete()
                                                    }
                                                }
                                                val plain = LyricsParser.parse(lrc).joinToString("\n") { it.text }
                                                if (plain.isBlank()) throw IllegalStateException("AI could not recognise clear lyrics in this song.")
                                                originalLyrics = plain
                                                syncedLyrics = lrc
                                                translatedLyrics = ""
                                                showTranslation = false
                                                lyricsStatus = "Offline transcription completed. Original lyrics are ready. Translation is not generated in offline mode; please review the words."
                                                withContext(Dispatchers.IO) {
                                                    LyricsCache.save(context, track.title, track.artist,
                                                        LyricsResult(originalLyrics, translatedLyrics, lyricsStatus, syncedLyrics))
                                                }
                                            } catch (error: Exception) {
                                                lyricsStatus = "Offline AI could not transcribe this track: ${error.message ?: "unknown error"}"
                                            } finally { aiTranscribing = false }
                                        }
                                    }
                                }
                            )
                        }
                    }
                }
                HorizontalDivider(Modifier.padding(vertical = 8.dp))
                Text(selectedTrack?.title ?: "Nothing playing", style = MaterialTheme.typography.titleMedium, maxLines = 1)
                Text(selectedTrack?.artist ?: "Choose a song from your library", style = MaterialTheme.typography.bodySmall, maxLines = 1)
                PlaybackVisualizer(isPlaying, Modifier.fillMaxWidth().height(30.dp))
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
                    IconButton(onClick = { shuffleEnabled = !shuffleEnabled; player.shuffleModeEnabled = shuffleEnabled }) {
                        Icon(Icons.Filled.Shuffle, "Shuffle", tint = if (shuffleEnabled) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToPreviousMediaItem() }) { Icon(Icons.Filled.SkipPrevious, "Previous") }
                    FilledIconButton(onClick = { if (player.isPlaying) player.pause() else if (selectedTrack != null) player.play() }, enabled = selectedTrack != null) {
                        Icon(if (isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow, if (isPlaying) "Pause" else "Play")
                    }
                    IconButton(onClick = { if (player.mediaItemCount > 0) player.seekToNextMediaItem() }) { Icon(Icons.Filled.SkipNext, "Next") }
                    IconButton(onClick = {
                        repeatMode = when (repeatMode) {
                            Player.REPEAT_MODE_OFF -> Player.REPEAT_MODE_ALL
                            Player.REPEAT_MODE_ALL -> Player.REPEAT_MODE_ONE
                            else -> Player.REPEAT_MODE_OFF
                        }; player.repeatMode = repeatMode
                    }) {
                        Icon(if (repeatMode == Player.REPEAT_MODE_ONE) Icons.Filled.RepeatOne else Icons.Filled.Repeat, "Repeat",
                            tint = if (repeatMode != Player.REPEAT_MODE_OFF) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
                Text(when (repeatMode) { Player.REPEAT_MODE_ONE -> "Repeat one"; Player.REPEAT_MODE_ALL -> "Repeat all"; else -> "Repeat off" },
                    modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp), textAlign = TextAlign.Center,
                    style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun LyricsScreen(
    track: MusicTrack?, original: String, translated: String, synced: String,
    positionMs: Long, isPlaying: Boolean, loading: Boolean, status: String,
    displayMode: Int, onDisplayModeChange: (Int) -> Unit,
    showTranslation: Boolean, onToggleTranslation: (Boolean) -> Unit,
    modifier: Modifier = Modifier, aiTranscribing: Boolean = false,
    onAiTranscribe: (String) -> Unit = { _ -> }, onImportLyrics: () -> Unit = {}
) {
    var aiLanguage by remember { mutableStateOf("auto") }
    val lines = remember(synced, original) {
        val parsed = LyricsParser.parse(synced)
        if (parsed.isNotEmpty()) parsed else original.lines().filter { it.isNotBlank() }.mapIndexed { index, line -> LyricLine(index * 5000L, line) }
    }
    val activeIndex = lines.indexOfLast { it.timeMs <= positionMs }.coerceAtLeast(0)
    val listState = rememberLazyListState()
    LaunchedEffect(activeIndex, displayMode, showTranslation) {
        if (lines.isNotEmpty()) listState.animateScrollToItem((activeIndex - 2).coerceAtLeast(0))
    }
    val translatedLines = remember(translated) { translated.lines() }
    Column(modifier) {
        Text("Live lyrics", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text(track?.let { "${it.title} • ${it.artist}" } ?: "No song selected", style = MaterialTheme.typography.bodySmall)
        if (loading) { LinearProgressIndicator(Modifier.fillMaxWidth()); Spacer(Modifier.height(8.dp)) }
        if (original.isNotBlank()) {
            Spacer(Modifier.height(8.dp))
            SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth()) {
                SegmentedButton(selected = displayMode == 0, onClick = { onDisplayModeChange(0) }, shape = SegmentedButtonDefaults.itemShape(0, 3)) { Text("Both") }
                SegmentedButton(selected = displayMode == 1, onClick = { onDisplayModeChange(1) }, shape = SegmentedButtonDefaults.itemShape(1, 3)) { Text("Translation") }
                SegmentedButton(selected = displayMode == 2, onClick = { onDisplayModeChange(2) }, shape = SegmentedButtonDefaults.itemShape(2, 3)) { Text("Toggle") }
            }
            if (displayMode == 2) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Lyrics language"); Spacer(Modifier.weight(1f))
                    Text(if (showTranslation) "Translation" else "Original", color = MaterialTheme.colorScheme.primary)
                    Switch(checked = showTranslation, onCheckedChange = onToggleTranslation, enabled = translated.isNotBlank())
                }
            }
            if (synced.isBlank()) Text("This song has plain lyrics only; line highlighting follows an estimated 5-second pace.", style = MaterialTheme.typography.labelSmall)
            LazyColumn(state = listState, modifier = Modifier.weight(1f).fillMaxWidth(), contentPadding = PaddingValues(vertical = 24.dp)) {
                itemsIndexed(lines) { index, line ->
                    val isActive = index == activeIndex
                    val translatedLine = translatedLines.getOrNull(index).orEmpty()
                    Column(Modifier.fillMaxWidth().padding(vertical = 9.dp)
                        .clip(RoundedCornerShape(16.dp))
                        .background(if (isActive) Color(0x332E8BFF) else Color.Transparent)
                        .padding(horizontal = 14.dp, vertical = 12.dp)) {
                        if (displayMode != 1) {
                            Text(line.text, style = if (isActive) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                color = if (isActive) Color(0xFF8CEBFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (displayMode == 0 || (displayMode == 2 && showTranslation)) {
                            val t = translatedLine.ifBlank { if (index == 0 && translatedLines.size != lines.size) translated else "" }
                            if (t.isNotBlank()) Text(t, modifier = Modifier.padding(top = 4.dp),
                                style = if (isActive) MaterialTheme.typography.titleMedium else MaterialTheme.typography.bodyMedium,
                                color = if (isActive) Color(0xFFC8BFFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        if (displayMode == 1 && translated.isNotBlank()) {
                            val t = translatedLine.ifBlank { if (index == 0) translated else "" }
                            if (t.isNotBlank()) Text(t, style = if (isActive) MaterialTheme.typography.titleLarge else MaterialTheme.typography.bodyLarge,
                                fontWeight = if (isActive) FontWeight.Bold else FontWeight.Normal,
                                color = if (isActive) Color(0xFF8CEBFF) else MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            }
        } else {
            Column(Modifier.weight(1f).fillMaxWidth(), verticalArrangement = Arrangement.Center, horizontalAlignment = Alignment.CenterHorizontally) {
                Text(if (loading) "Looking for lyrics…" else status, textAlign = TextAlign.Center)
                if (!loading && track != null) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedButton(onClick = onImportLyrics, enabled = !aiTranscribing) {
                        Text("Import .LRC / .TXT")
                    }
                    Spacer(Modifier.height(6.dp))
                    Text("Recognition language", style = MaterialTheme.typography.labelMedium)
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.Center) {
                        listOf("auto" to "Auto", "ta" to "Tamil", "en" to "English").forEach { (code, label) ->
                            TextButton(onClick = { aiLanguage = code }, enabled = !aiTranscribing) {
                                Text(if (aiLanguage == code) "✓ $label" else label)
                            }
                        }
                    }
                    Button(onClick = { onAiTranscribe(aiLanguage) }, enabled = !aiTranscribing) {
                        if (aiTranscribing) CircularProgressIndicator(Modifier.size(18.dp), strokeWidth = 2.dp)
                        else Icon(Icons.Filled.Mic, contentDescription = null)
                        Spacer(Modifier.width(8.dp))
                        Text(if (aiTranscribing) "Transcribing on device…" else "Try offline AI lyrics")
                    }
                    Text("Uses the AI model included in this app. Song audio stays on your phone.",
                        style = MaterialTheme.typography.labelSmall, textAlign = TextAlign.Center)
                }
            }
        }
        if (status.isNotBlank() && (original.isNotBlank() || aiTranscribing)) Text(
            status, style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        Text("Word-level timing is shown only when supplied by the lyrics source. Lyrics saved on this phone remain available offline.",
            style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun PlaybackVisualizer(isPlaying: Boolean, modifier: Modifier = Modifier) {
    val transition = rememberInfiniteTransition(label = "visualizer")
    val phase by transition.animateFloat(0f, (2f * PI).toFloat(),
        animationSpec = infiniteRepeatable(tween(900, easing = LinearEasing), RepeatMode.Restart), label = "phase")
    Canvas(modifier) {
        val count = thirtyBars
        val gap = size.width * 0.012f
        val barWidth = (size.width - gap * (count - 1)) / count
        for (i in 0 until count) {
            val wave = (sin(phase + i * 0.72f) * 0.5f + 0.5f)
            val height = if (isPlaying) size.height * (0.18f + wave * 0.78f) else size.height * 0.12f
            drawRoundRect(
                color = Color(0xFF5D75FF).copy(alpha = if (isPlaying) 0.55f + wave * 0.4f else 0.25f),
                topLeft = androidx.compose.ui.geometry.Offset(i * (barWidth + gap), (size.height - height) / 2),
                size = androidx.compose.ui.geometry.Size(barWidth, height),
                cornerRadius = androidx.compose.ui.geometry.CornerRadius(barWidth / 2)
            )
        }
    }
}
private const val thirtyBars = 30

@Composable
private fun EqualizerScreen(controller: AudioEffectsController?) {
    var bass by remember(controller) { mutableFloatStateOf(controller?.bassStrength?.toFloat() ?: 0f) }
    val levels = remember(controller) {
        mutableStateListOf<Float>().apply {
            if (controller != null) for (i in 0 until controller.bandCount) add(controller.getBandLevel(i).toFloat() / 100f)
        }
    }
    Column(Modifier.fillMaxSize()) {
        Text("Audio equalizer", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Adjust the sound for this device's audio engine.", style = MaterialTheme.typography.bodySmall)
        Spacer(Modifier.height(12.dp))
        if (controller == null) {
            Text("The device audio equalizer is not available yet. Start playback and reopen this screen.", textAlign = TextAlign.Center)
        } else {
            Text("Frequency bands (${controller.bandCount} supported)", fontWeight = FontWeight.SemiBold)
            LazyColumn(Modifier.weight(1f)) {
                itemsIndexed(levels) { index, level ->
                    Column(Modifier.fillMaxWidth().padding(vertical = 5.dp)) {
                        Row { Text(controller.bandLabel(index)); Spacer(Modifier.weight(1f)); Text("${(level / 10f).toInt()} dB") }
                        Slider(value = level, onValueChange = {
                            levels[index] = it
                            controller.setBandLevel(index, (it * 100f).toInt())
                        }, valueRange = -15f..15f)
                    }
                }
                item {
                    Spacer(Modifier.height(8.dp))
                    Text("Bass boost", fontWeight = FontWeight.SemiBold)
                    Slider(value = bass, onValueChange = { bass = it; controller.setBassStrength(it.toInt() * 10) }, valueRange = 0f..100f)
                    Text("${bass.toInt()}%")
                }
            }
        }
        Text("Available frequency bands depend on your phone's audio hardware.", style = MaterialTheme.typography.labelSmall)
    }
}
