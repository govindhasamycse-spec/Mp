package com.example.universalmusicplayer

import android.content.Context
import java.io.DataInputStream
import java.io.BufferedInputStream
import java.io.File
import java.io.FileInputStream

/** Reuses one native Whisper context and feeds it bounded audio windows. */
object WhisperNative {
    init { System.loadLibrary("whisper_jni") }

    private external fun nativeCreateContext(modelPath: String): Long
    private external fun nativeTranscribeChunk(
        contextHandle: Long, audio16kMono: FloatArray, language: String, offsetMs: Long
    ): String
    private external fun nativeFreeContext(contextHandle: Long)

    fun transcribeFromAssets(
        context: Context,
        decoded: AndroidAudioDecoder.DecodedPcm,
        language: String = "auto",
        onProgress: (Int, Int) -> Unit = { _, _ -> },
        onStatus: (String) -> Unit = {}
    ): String {
        require(decoded.sampleCount > 0L) { "No decoded audio was available." }
        onStatus("Preparing the bundled offline AI model…")
        val model = File(context.filesDir, "ggml-tiny.bin")
        if (!model.exists() || model.length() != 77_691_713L) {
            val temp = File(context.cacheDir, "ggml-tiny.bin.part")
            context.assets.open("models/ggml-tiny.bin").use { input ->
                temp.outputStream().buffered().use { output -> input.copyTo(output) }
            }
            require(temp.length() == 77_691_713L) { "Bundled Whisper model is incomplete." }
            if (model.exists()) model.delete()
            check(temp.renameTo(model)) { "Could not prepare the offline AI model." }
        }

        onStatus("Loading Whisper Tiny into memory…")
        val sourceSamplesPerChunk = decoded.sampleRate * 25
        val totalChunks = ((decoded.sampleCount + sourceSamplesPerChunk - 1) / sourceSamplesPerChunk).toInt()
        val handle = nativeCreateContext(model.absolutePath)
        check(handle != 0L) { "Could not load the offline AI model." }
        onStatus("Model ready. Starting offline transcription…")
        val result = StringBuilder()
        try {
            DataInputStream(BufferedInputStream(FileInputStream(decoded.file), 256 * 1024)).use { input ->
                var remaining = decoded.sampleCount
                var chunkIndex = 0
                while (remaining > 0) {
                    val count = minOf(sourceSamplesPerChunk.toLong(), remaining).toInt()
                    val source = FloatArray(count) { input.readFloat() }
                    val samples16k = AndroidAudioDecoder.resampleWindow(source, decoded.sampleRate)
                    val offsetMs = chunkIndex.toLong() * 25_000L
                    val part = nativeTranscribeChunk(handle, samples16k, language, offsetMs)
                    if (part.isNotBlank()) {
                        if (result.isNotEmpty()) result.append('\n')
                        result.append(part.trim())
                    }
                    remaining -= count
                    chunkIndex++
                    onProgress(chunkIndex, totalChunks)
                }
            }
        } finally {
            nativeFreeContext(handle)
        }
        return result.toString()
    }
}
