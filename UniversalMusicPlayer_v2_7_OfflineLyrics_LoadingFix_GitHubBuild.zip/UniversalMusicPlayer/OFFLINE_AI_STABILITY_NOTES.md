# v2.7 Dev 2 – Offline AI stability update

This source update responds to reported 5–10 minute Tamil-song tests where the app froze and closed.

Changes:
- Decodes mono PCM incrementally to a temporary cache file rather than retaining boxed Float objects and multiple full-song arrays in RAM.
- Processes audio in 25-second windows, keeping the per-inference audio buffer bounded.
- Loads one Whisper context per transcription and reuses it for all windows; frees it in a finally block.
- Uses two inference threads instead of four as a conservative mobile-device starting point.
- Adds an in-player recognition-language selector: Auto, Tamil, or English. Tamil can be forced for Tamil songs rather than relying on automatic language detection over music.
- Adds chunk progress text to the existing lyrics status area.
- Deletes the temporary PCM file after transcription, including on failure.
- Keeps Whisper Tiny multilingual and offline; language remains automatic in this revision.

Known limitations:
- This is a source-code update, not a verified APK. Android/NDK compilation and phone testing have not yet been performed.
- Tamil singing recognition quality is not guaranteed to improve just from memory fixes. Tiny may still mishear lyrics under music; this needs device testing.
- 25-second chunk boundaries can split words/phrases. Word-level karaoke alignment is not implemented.
- Translation remains a separate online step in the existing app; transcription itself is on-device.
- If the app still crashes, collect Android crash/logcat output before changing model size or inference settings.


## v2.7 loading/visibility follow-up
- Shows model-copy/model-load status and chunk progress even before any lyrics have been produced.
- Removes the online line-by-line translation request from the offline AI transcription path. A local transcription now returns and displays the original recognized lyrics without waiting for internet translation.
- Translation remains blank for AI-generated lyrics in this offline path; the app explicitly tells the user rather than appearing to load indefinitely.
- This is still source only. Build and device validation are required.
